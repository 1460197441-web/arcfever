@echo off
set PORT=8080
node server.cjs
pause
