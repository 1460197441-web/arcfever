<template>
  <view class="page-shell">
    <view class="topbar">
      <text class="brand">Profile.</text>
    </view>

    <view v-if="loading" class="loading-state">正在加载个人中心...</view>

    <view v-else>
      <view class="screen-pad">
        <view class="author-row">
          <view class="author-left">
            <view class="avatar a1"></view>
            <view>
              <view class="author-name-row">
                <text class="author-name">{{ profile.certification.name || '待补充姓名' }}</text>
                <view v-if="profile.certification.status === '已认证'" class="verify-badge">V</view>
              </view>
              <text class="author-inst">{{ profile.certification.role }} · {{ profile.certification.school || '待选择学校' }}</text>
            </view>
          </view>
        </view>
      </view>

      <view class="hero-copy" style="padding: 0 24rpx;">{{ profile.certification.pendingMessage }}</view>

      <view class="info-grid section-space">
        <view class="info-card">
          <view class="info-label">联系电话</view>
          <view class="info-value">{{ profile.certification.phone || '未填写' }}</view>
        </view>
        <view class="info-card">
          <view class="info-label">机构邮箱</view>
          <view class="info-value">{{ profile.certification.email || '未填写' }}</view>
        </view>
        <view class="info-card">
          <view class="info-label">我的仪器</view>
          <view class="info-value">{{ profile.instrumentCount }}</view>
        </view>
        <view class="info-card">
          <view class="info-label">订单数量</view>
          <view class="info-value">{{ profile.orderCount }}</view>
        </view>
      </view>

      <view class="section list-stack top-gap">
        <view class="card" @tap="goPage('/pages/certification/index')">
          <view class="feature-title">认证信息</view>
          <view class="feature-copy">{{ profile.certification.status }}</view>
        </view>
        <view class="card" @tap="goPage('/pages/my-instruments/index')">
          <view class="feature-title">我发布的</view>
          <view class="feature-copy">管理个人设备</view>
        </view>
        <view class="card" @tap="goPage('/pages/order-list/index')">
          <view class="feature-title">订单列表</view>
          <view class="feature-copy">查看交易进度</view>
        </view>
        <view class="card" @tap="goPage('/pages/favorites/index')">
          <view class="feature-title">我的收藏</view>
          <view class="feature-copy">仪器收藏夹</view>
        </view>
      </view>
    </view>

    <BottomTabBar current="/pages/profile/index" />
  </view>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { onShow } from '@dcloudio/uni-app'
import BottomTabBar from '../../components/BottomTabBar.vue'
import { callService } from '../../common/service'

const loading = ref(true)
const profile = ref(null)

async function loadData() {
  loading.value = true
  profile.value = await callService('getProfile')
  loading.value = false
}

onMounted(loadData)
onShow(loadData)

function goPage(url) {
  uni.navigateTo({ url })
}
</script>
