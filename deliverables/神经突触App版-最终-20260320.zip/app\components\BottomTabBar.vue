<template>
  <view class="tab-shell">
    <view
      v-for="item in tabs"
      :key="item.path"
      class="tab-item"
      :class="{ active: current === item.path, center: item.key === 'publish' }"
      @tap="switchTab(item.path)"
    >
      <view v-if="item.key === 'publish'" class="center-plus">+</view>
      <image v-else class="tab-icon-image" :src="current === item.path ? item.activeIcon : item.icon" mode="aspectFit" />
      <text class="tab-text">{{ item.label }}</text>
    </view>
  </view>
</template>

<script setup>
function makeIcon(body) {
  return `data:image/svg+xml;utf8,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">${body}</svg>`)}`
}

const props = defineProps({
  current: {
    type: String,
    default: ''
  }
})

const tabs = [
  {
    path: '/pages/home/index',
    label: '首页',
    key: 'home',
    icon: makeIcon('<path d="M4.8 10.5 12 4.7l7.2 5.8V19a1 1 0 0 1-1 1H5.8a1 1 0 0 1-1-1z" fill="none" stroke="#9CA3AF" stroke-width="1.8" stroke-linejoin="round"/><path d="M9.6 20v-5.2h4.8V20" fill="none" stroke="#9CA3AF" stroke-width="1.8" stroke-linejoin="round"/>'),
    activeIcon: makeIcon('<path d="M4.6 10.3 12 4.2l7.4 6.1V19a1.2 1.2 0 0 1-1.2 1.2H5.8A1.2 1.2 0 0 1 4.6 19z" fill="#111111"/><path d="M9.8 20v-5.3h4.4V20" fill="#ffffff"/>')
  },
  {
    path: '/pages/category/index',
    label: '分类',
    key: 'category',
    icon: makeIcon('<rect x="4.5" y="4.5" width="6.2" height="6.2" rx="1.2" fill="none" stroke="#9CA3AF" stroke-width="1.7"/><rect x="13.3" y="4.5" width="6.2" height="6.2" rx="1.2" fill="none" stroke="#9CA3AF" stroke-width="1.7"/><rect x="4.5" y="13.3" width="6.2" height="6.2" rx="1.2" fill="none" stroke="#9CA3AF" stroke-width="1.7"/><rect x="13.3" y="13.3" width="6.2" height="6.2" rx="1.2" fill="none" stroke="#9CA3AF" stroke-width="1.7"/>'),
    activeIcon: makeIcon('<rect x="4.2" y="4.2" width="6.8" height="6.8" rx="1.4" fill="#111111"/><rect x="13" y="4.2" width="6.8" height="6.8" rx="1.4" fill="#111111"/><rect x="4.2" y="13" width="6.8" height="6.8" rx="1.4" fill="#111111"/><rect x="13" y="13" width="6.8" height="6.8" rx="1.4" fill="#111111"/>')
  },
  { path: '/pages/publish/index', label: '发布', key: 'publish' },
  {
    path: '/pages/messages/index',
    label: '消息',
    key: 'messages',
    icon: makeIcon('<path d="M5.2 6.3h13.6a1.6 1.6 0 0 1 1.6 1.6v8.1a1.6 1.6 0 0 1-1.6 1.6H11l-4.4 3v-3H5.2A1.6 1.6 0 0 1 3.6 16V7.9a1.6 1.6 0 0 1 1.6-1.6Z" fill="none" stroke="#9CA3AF" stroke-width="1.7" stroke-linejoin="round"/>'),
    activeIcon: makeIcon('<path d="M5 5.8h14a1.8 1.8 0 0 1 1.8 1.8v8.6A1.8 1.8 0 0 1 19 18H11.2l-4.8 3.2V18H5a1.8 1.8 0 0 1-1.8-1.8V7.6A1.8 1.8 0 0 1 5 5.8Z" fill="#111111"/>')
  },
  {
    path: '/pages/profile/index',
    label: '我的',
    key: 'profile',
    icon: makeIcon('<circle cx="12" cy="8.1" r="3.2" fill="none" stroke="#9CA3AF" stroke-width="1.7"/><path d="M5.4 18.3c1.5-2.6 4-3.9 6.6-3.9s5.1 1.3 6.6 3.9" fill="none" stroke="#9CA3AF" stroke-width="1.7" stroke-linecap="round"/>'),
    activeIcon: makeIcon('<circle cx="12" cy="8" r="3.4" fill="#111111"/><path d="M4.8 19c1.6-2.9 4.4-4.3 7.2-4.3s5.6 1.4 7.2 4.3" fill="#111111"/>')
  }
]

function switchTab(path) {
  if (path === props.current) return
  uni.reLaunch({ url: path })
}
</script>

<style scoped lang="scss">
.tab-shell {
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 90;
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  padding: 14rpx 34rpx calc(14rpx + env(safe-area-inset-bottom));
  background: rgba(255, 255, 255, 0.98);
}

.tab-item {
  width: 104rpx;
  min-height: 94rpx;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8rpx;
  color: #9ca3af;
}

.tab-item.active {
  color: #111111;
}

.tab-item.center {
  margin-top: -18rpx;
}

.tab-icon-image {
  width: 40rpx;
  height: 40rpx;
}

.tab-text {
  font-size: 20rpx;
  line-height: 1;
}

.center-plus {
  width: 88rpx;
  height: 88rpx;
  border-radius: 999rpx;
  background: #111111;
  color: #ffffff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 44rpx;
  font-weight: 300;
}

.tab-item.active .center-plus {
  background: #0ea5e9;
}
</style>
