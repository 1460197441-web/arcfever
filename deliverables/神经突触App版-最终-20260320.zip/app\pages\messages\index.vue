<template>
  <view class="page-shell">
    <view class="topbar">
      <text class="brand">Messages.</text>
    </view>

    <view class="hero-panel">
      <view class="hero-tag">消息中心</view>
      <view class="hero-title small">查看设备沟通、排期确认与平台介入进度</view>
      <view class="hero-copy">会话页承接仪器咨询、订单确认、保险与纠纷前沟通。你和发布方的关键确认都会在这里留痕。</view>
    </view>

    <view v-if="loading" class="loading-state">正在同步会话列表...</view>

    <view v-else class="section list-stack">
      <view v-for="(item, index) in list" :key="item.id" class="card" @tap="openChat(item.id)">
        <view class="author-row">
          <view class="author-left">
            <view class="avatar" :class="`a${(index % 4) + 1}`"></view>
            <view>
              <view class="author-name-row">
                <text class="author-name">{{ item.counterpartName || item.sellerName }}</text>
                <view class="verify-badge">V</view>
              </view>
              <text class="author-inst">{{ item.counterpartRole || item.sellerRole }} · {{ item.instrumentName }}</text>
            </view>
          </view>
          <text class="author-inst">{{ item.updatedAt }}</text>
        </view>
        <view class="feature-copy">{{ item.lastMessage }}</view>
      </view>
    </view>

    <BottomTabBar current="/pages/messages/index" />
  </view>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { onShow } from '@dcloudio/uni-app'
import BottomTabBar from '../../components/BottomTabBar.vue'
import { callService } from '../../common/service'

const loading = ref(true)
const list = ref([])

async function loadData() {
  loading.value = true
  const res = await callService('getChatList')
  list.value = res.list
  loading.value = false
}

onMounted(loadData)
onShow(loadData)

function openChat(id) {
  uni.navigateTo({ url: `/pages/chat-detail/index?id=${id}` })
}
</script>
