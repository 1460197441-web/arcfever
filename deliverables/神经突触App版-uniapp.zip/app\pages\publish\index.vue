<template>
  <view class="page-shell">
    <view class="topbar">
      <text class="brand">Publish.</text>
    </view>

    <view class="hero-panel">
      <view class="hero-tag">发布仪器</view>
      <view class="hero-title small">可租赁，也可出售</view>
      <view class="hero-copy">App 版保留和小程序同样的发布口径：租售模式、押金、精度参数、远程实验、数据包和违约条款都在一页配置。</view>
    </view>

    <view class="section">
      <view class="card panel">
        <view class="form-label">仪器名称</view>
        <input v-model="form.name" class="form-input" placeholder="请输入仪器名称" />

        <view class="form-label top-gap">分类</view>
        <picker :range="categories" :value="categoryIndex" @change="onCategoryChange">
          <view class="picker-box">{{ categories[categoryIndex] || '请选择分类' }}</view>
        </picker>

        <view class="form-label top-gap">交易模式</view>
        <view class="chip-row">
          <view v-for="mode in tradeModes" :key="mode" class="chip" :class="{ active: form.tradeModes.includes(mode) }" @tap="toggleMode(mode)">
            {{ mode }}
          </view>
        </view>

        <view class="form-label top-gap">租赁日价</view>
        <input v-model="form.price" class="form-input" placeholder="请输入价格 / 天" />

        <view class="form-label top-gap">买断价格</view>
        <input v-model="form.salePrice" class="form-input" placeholder="若支持出售，请填写买断价格" />

        <view class="form-label top-gap">押金</view>
        <input v-model="form.deposit" class="form-input" placeholder="租赁场景建议填写押金" />

        <view class="form-label top-gap">所在城市</view>
        <input v-model="form.location" class="form-input" placeholder="请输入城市与交接区域" />

        <view class="form-label top-gap">精度参数</view>
        <input v-model="form.precision" class="form-input" placeholder="例如：误差小于 2 kPa" />

        <view class="form-label top-gap">适用学科</view>
        <input v-model="form.disciplines" class="form-input" placeholder="多个学科可用顿号分隔" />

        <view class="form-label top-gap">服务包说明</view>
        <input v-model="form.servicePackage" class="form-input" placeholder="例如：附带标准数据包与处理代码" />

        <view class="form-label top-gap">科研描述</view>
        <textarea v-model="form.desc" class="form-textarea" placeholder="说明设备适用方向、交付内容与约束条件"></textarea>

        <view class="primary-btn full-btn top-gap" @tap="submit">确认发布</view>
      </view>
    </view>

    <BottomTabBar current="/pages/publish/index" />
  </view>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import BottomTabBar from '../../components/BottomTabBar.vue'
import { callService } from '../../common/service'

const categories = ref([])
const categoryIndex = ref(0)
const tradeModes = ['租赁', '出售']
const form = reactive({
  name: '',
  category: '海洋观测',
  tradeModes: ['租赁'],
  price: '',
  salePrice: '',
  deposit: '',
  location: '',
  precision: '',
  disciplines: '',
  servicePackage: '',
  desc: '',
  withDataPackage: true,
  remote: false
})

onMounted(async () => {
  const res = await callService('getCategories')
  categories.value = res.categories.filter((item) => item !== '全部')
  form.category = categories.value[0]
})

function onCategoryChange(event) {
  categoryIndex.value = Number(event.detail.value)
  form.category = categories.value[categoryIndex.value]
}

function toggleMode(mode) {
  if (form.tradeModes.includes(mode)) {
    form.tradeModes = form.tradeModes.filter((item) => item !== mode)
  } else {
    form.tradeModes = [...form.tradeModes, mode]
  }
}

async function submit() {
  await callService('publishInstrument', {
    ...form,
    price: Number(form.price || 0),
    salePrice: Number(form.salePrice || 0),
    deposit: Number(form.deposit || 0),
    disciplines: form.disciplines ? form.disciplines.split(/[、,，]/).map((item) => item.trim()).filter(Boolean) : []
  })
  uni.showToast({ title: '发布成功', icon: 'success' })
}
</script>
