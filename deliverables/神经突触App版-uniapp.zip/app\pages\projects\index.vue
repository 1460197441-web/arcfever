<template>
  <view class="page-shell">
    <view class="hero-panel">
      <view class="hero-tag">项目协作</view>
      <view class="hero-title small">研发需求、匹配团队与人才评估</view>
      <view class="hero-copy">项目协作页沿用小程序的白底极简结构，把科研合作做成可管理的需求流和候选团队流。</view>
    </view>

    <view class="section chip-row">
      <view v-for="item in filters" :key="item" class="chip" :class="{ active: activeFilter === item }" @tap="activeFilter = item">
        {{ item }}
      </view>
    </view>

    <view class="section list-stack top-gap">
      <view v-for="item in filteredList" :key="item.id" class="card" @tap="openProject(item.id)">
        <view class="feature-top">
          <view class="feature-title">{{ item.title }}</view>
          <view class="badge">{{ item.status }}</view>
        </view>
        <view class="feature-copy">{{ item.intro }}</view>
      </view>
    </view>
  </view>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { callService } from '../../common/service'

const filters = ref(['全部'])
const list = ref([])
const activeFilter = ref('全部')

const filteredList = computed(() => (activeFilter.value === '全部' ? list.value : list.value.filter((item) => item.domain === activeFilter.value)))

onMounted(async () => {
  const res = await callService('getProjects')
  filters.value = res.filters
  list.value = res.list
})

function openProject(id) {
  uni.navigateTo({ url: `/pages/project-detail/index?id=${id}` })
}
</script>
