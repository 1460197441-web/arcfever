<template>
  <view class="tab-shell">
    <view
      v-for="item in tabs"
      :key="item.path"
      class="tab-item"
      :class="{ active: current === item.path, center: item.key === 'publish' }"
      @tap="switchTab(item.path)"
    >
      <view v-if="item.key === 'publish'" class="center-plus">+</view>
      <view v-else class="tab-icon">{{ item.icon }}</view>
      <text class="tab-text">{{ item.label }}</text>
    </view>
  </view>
</template>

<script setup>
const props = defineProps({
  current: {
    type: String,
    default: ''
  }
})

const tabs = [
  { path: '/pages/home/index', label: '首页', key: 'home', icon: '⌂' },
  { path: '/pages/category/index', label: '分类', key: 'category', icon: '◎' },
  { path: '/pages/publish/index', label: '发布', key: 'publish', icon: '+' },
  { path: '/pages/messages/index', label: '消息', key: 'messages', icon: '◌' },
  { path: '/pages/profile/index', label: '我的', key: 'profile', icon: '◔' }
]

function switchTab(path) {
  if (path === props.current) return
  uni.reLaunch({ url: path })
}
</script>

<style scoped lang="scss">
.tab-shell {
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 90;
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  padding: 14rpx 34rpx calc(14rpx + env(safe-area-inset-bottom));
  background: rgba(255, 255, 255, 0.98);
}

.tab-item {
  width: 104rpx;
  min-height: 94rpx;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8rpx;
  color: #9ca3af;
}

.tab-item.active {
  color: #111111;
}

.tab-item.center {
  margin-top: -18rpx;
}

.tab-icon {
  font-size: 36rpx;
  line-height: 1;
}

.tab-text {
  font-size: 20rpx;
  line-height: 1;
}

.center-plus {
  width: 88rpx;
  height: 88rpx;
  border-radius: 999rpx;
  background: #111111;
  color: #ffffff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 44rpx;
  font-weight: 300;
}

.tab-item.active .center-plus {
  background: #0ea5e9;
}
</style>
