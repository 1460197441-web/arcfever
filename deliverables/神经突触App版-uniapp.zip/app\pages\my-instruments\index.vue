<template>
  <view class="page-shell">
    <view class="hero-panel">
      <view class="hero-tag">我的仪器</view>
      <view class="hero-title small">管理你发布的设备</view>
      <view class="hero-copy">这里只有你自己发布成功的仪器。首页和分类页看到的是平台市场里的仪器，不代表是你上传的。</view>
    </view>

    <view v-if="!list.length" class="section">
      <view class="card">
        <view class="empty-title">你还没有发布过仪器</view>
        <view class="empty-copy">等你自己发布后，这里才会出现你的仪器。</view>
      </view>
    </view>

    <view v-else class="section list-stack">
      <view v-for="item in list" :key="item.id" class="card">
        <view class="feature-title">{{ item.name }}</view>
        <view class="feature-copy">{{ item.desc }}</view>
      </view>
    </view>
  </view>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { onShow } from '@dcloudio/uni-app'
import { callService } from '../../common/service'

const list = ref([])

async function loadData() {
  const res = await callService('getMyInstruments')
  list.value = res.list
}

onMounted(loadData)
onShow(loadData)
</script>
