<template>
  <view class="page-shell">
    <view class="hero-panel">
      <view class="hero-tag">科研社区</view>
      <view class="hero-title small">仪器经验、协作记录与真实交流</view>
      <view class="hero-copy">社区模块延续小程序的科研专业感，让仪器交易不只是撮合，还能沉淀方法论和信任内容。</view>
    </view>

    <view class="section chip-row">
      <view v-for="tag in tags" :key="tag" class="chip" :class="{ active: activeTag === tag }" @tap="activeTag = tag">
        {{ tag }}
      </view>
    </view>

    <view class="section list-stack top-gap">
      <view v-for="item in filteredList" :key="item.id" class="card" @tap="openPost(item.id)">
        <view class="chip">{{ item.tag }}</view>
        <view class="feature-title top-gap">{{ item.title }}</view>
        <view class="feature-copy">{{ item.excerpt }}</view>
      </view>
    </view>
  </view>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { callService } from '../../common/service'

const tags = ref(['全部'])
const list = ref([])
const activeTag = ref('全部')

const filteredList = computed(() => (activeTag.value === '全部' ? list.value : list.value.filter((item) => item.tag === activeTag.value)))

onMounted(async () => {
  const res = await callService('getCommunity')
  tags.value = res.tags
  list.value = res.list
})

function openPost(id) {
  uni.navigateTo({ url: `/pages/post-detail/index?id=${id}` })
}
</script>
