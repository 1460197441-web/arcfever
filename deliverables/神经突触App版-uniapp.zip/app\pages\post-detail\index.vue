<template>
  <view class="page-shell">
    <view class="hero-panel">
      <view class="chip">{{ post.tag }}</view>
      <view class="hero-title small">{{ post.title }}</view>
      <view class="hero-copy">{{ post.author }} · {{ post.likes }} 赞 · {{ post.comments }} 评论</view>
    </view>

    <view class="section">
      <view class="card">
        <view class="post-content">{{ post.content }}</view>
      </view>
    </view>
  </view>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { callService } from '../../common/service'

const post = ref({ tag: '', title: '', author: '', likes: 0, comments: 0, content: '' })

onMounted(async () => {
  const pages = getCurrentPages()
  const current = pages[pages.length - 1]
  const postId = current && current.options ? current.options.id : ''
  const res = await callService('getPostDetail', { id: postId })
  post.value = res.post
})
</script>
