<template>
  <view class="page-shell">
    <view class="hero-panel">
      <view class="hero-title small">{{ project.title }}</view>
      <view class="hero-copy">{{ project.domain }} · {{ project.owner }}</view>
      <view class="chip-row top-gap">
        <view v-for="item in project.targetRoles" :key="item" class="chip">{{ item }}</view>
      </view>
    </view>

    <view class="section list-stack">
      <view class="card">
        <view class="section-title">项目信息</view>
        <view class="feature-copy">预算区间：{{ project.budget }}</view>
        <view class="feature-copy">合作周期：{{ project.duration }}</view>
      </view>
      <view class="card">
        <view class="section-title">评估维度</view>
        <view class="feature-copy">硬指标：{{ project.evaluation.hard }}</view>
        <view class="feature-copy">软评价：{{ project.evaluation.soft }}</view>
      </view>
      <view class="card">
        <view class="section-title">推荐人才</view>
        <view v-for="item in project.matches" :key="item.name" class="feature-copy">{{ item.name }} · {{ item.title }} · {{ item.score }} 分</view>
      </view>
    </view>
  </view>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { callService } from '../../common/service'

const project = ref({ targetRoles: [], evaluation: {}, matches: [] })

onMounted(async () => {
  const pages = getCurrentPages()
  const current = pages[pages.length - 1]
  const projectId = current && current.options ? current.options.id : ''
  const res = await callService('getProjectDetail', { id: projectId })
  project.value = res.project
})
</script>
