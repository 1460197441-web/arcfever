<template>
  <view class="page-shell">
    <view class="topbar">
      <text class="brand">Discover.</text>
      <view class="topbar-actions">
        <text class="topbar-icon">⌕</text>
      </view>
    </view>

    <view class="hero-panel">
      <view class="hero-tag">分类与广场</view>
      <view class="hero-title small">按方向筛选平台在架仪器</view>
      <view class="hero-copy">App 版保留和小程序相同的分类浏览逻辑，同时把院校认证信息融入筛选场景，方便你边看设备边核验可信度。</view>
    </view>

    <view class="section">
      <view class="chip-row">
        <view v-for="item in categories" :key="item" class="chip" :class="{ active: activeCategory === item }" @tap="chooseCategory(item)">
          {{ item }}
        </view>
      </view>
    </view>

    <view class="section top-gap">
      <view class="search-box">
        <text>搜</text>
        <input class="search-input" v-model="keyword" placeholder="搜索仪器、学校、标签" @input="loadData" />
      </view>
    </view>

    <view v-if="loading" class="loading-state">正在获取仪器列表...</view>

    <view v-else>
      <view class="section list-stack">
        <view v-for="item in list" :key="item.id" class="card" @tap="openInstrument(item.id)">
          <view class="feature-top">
            <view>
              <view class="feature-title">{{ item.name }}</view>
              <view class="meta-text">{{ item.school }} / {{ item.college }}</view>
            </view>
            <view class="feature-price">{{ item.priceLabel }}</view>
          </view>
          <view class="feature-copy">{{ item.desc }}</view>
          <view class="chip-row top-gap">
            <view v-for="mode in item.tradeModes" :key="mode" class="chip" :class="{ active: mode === item.defaultTradeMode }">{{ mode }}</view>
          </view>
        </view>
      </view>

      <view class="section top-gap">
        <view class="section-head">
          <view>
            <view class="section-title">认证院校</view>
            <view class="section-subtitle">认证时从这里联动选择学校和学院。</view>
          </view>
        </view>
        <view class="list-stack">
          <view v-for="item in schools" :key="item.id" class="card">
            <view class="feature-title">{{ item.name }}</view>
            <view class="feature-copy">{{ item.collegesText }}</view>
          </view>
        </view>
      </view>
    </view>

    <view class="floating-cart" @tap="goCart">购物车</view>
    <BottomTabBar current="/pages/category/index" />
  </view>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import BottomTabBar from '../../components/BottomTabBar.vue'
import { callService } from '../../common/service'

const loading = ref(true)
const categories = ref([])
const schools = ref([])
const list = ref([])
const activeCategory = ref('全部')
const keyword = ref('')

onMounted(async () => {
  const pages = getCurrentPages()
  const current = pages[pages.length - 1]
  const initial = current && current.options ? current.options.category : ''
  if (initial) activeCategory.value = decodeURIComponent(initial)
  await loadData()
})

async function loadData() {
  loading.value = true
  const categoryRes = await callService('getCategories')
  const listRes = await callService('getInstruments', { category: activeCategory.value, keyword: keyword.value })
  categories.value = categoryRes.categories
  schools.value = categoryRes.schools
  list.value = listRes.list
  loading.value = false
}

function chooseCategory(category) {
  activeCategory.value = category
  loadData()
}

function openInstrument(id) {
  uni.navigateTo({ url: `/pages/equipment-detail/index?id=${id}` })
}

function goCart() {
  uni.navigateTo({ url: '/pages/cart/index' })
}
</script>
