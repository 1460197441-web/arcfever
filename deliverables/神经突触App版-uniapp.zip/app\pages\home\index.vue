<template>
  <view class="page-shell">
    <view class="topbar">
      <text class="brand">Synaptic.</text>
      <view class="topbar-actions">
        <text class="topbar-icon">⌕</text>
      </view>
    </view>

    <scroll-view scroll-x class="screen-pad" style="white-space: nowrap;">
      <view v-for="(tag, index) in categories" :key="tag" class="tag-pill" :class="{ active: index === 0 }" @tap="openCategory(tag)">
        {{ tag }}
      </view>
    </scroll-view>

    <view v-if="loading" class="loading-state">正在生成首页内容...</view>

    <view v-else>
      <view class="panel-title">{{ homeData.hero.title }}</view>
      <view class="hero-copy" style="padding: 0 24rpx;">{{ homeData.hero.subtitle }}</view>

      <view class="stat-strip">
        <view v-for="item in homeData.stats" :key="item.label" class="stat-card">
          <view class="stat-value">{{ item.value }}</view>
          <view class="stat-label">{{ item.label }}</view>
        </view>
      </view>

      <view class="market-strip">
        <view class="market-note">
          <text class="market-emphasis">当前首页展示的是平台广场中的在架仪器。</text>
          它们属于平台冷启动库存或其他认证用户发布，不代表你自己的账号已经上传过设备。
        </view>
      </view>

      <view class="module-grid section-space" style="padding: 0 24rpx;">
        <view class="module-card" @tap="goPage('/pages/community/index')">
          <view class="feature-title">科研社区</view>
          <view class="feature-copy">经验内容与协作复盘</view>
        </view>
        <view class="module-card" @tap="goPage('/pages/projects/index')">
          <view class="feature-title">项目协作</view>
          <view class="feature-copy">需求撮合与人才评估</view>
        </view>
        <view class="module-card" @tap="goPage('/pages/remote-lab/index')">
          <view class="feature-title">远程实验</view>
          <view class="feature-copy">代测、排期与交付</view>
        </view>
        <view class="module-card" @tap="goPage('/pages/ai-tools/index')">
          <view class="feature-title">AI 工具</view>
          <view class="feature-copy">分析与资源匹配</view>
        </view>
      </view>

      <view class="feed-list">
        <view v-for="(item, index) in homeData.featuredInstruments" :key="item.id" class="feed-item">
          <view class="author-row">
            <view class="author-left">
              <view class="avatar" :class="item.avatarClass || `a${(index % 4) + 1}`"></view>
              <view>
                <view class="author-name-row">
                  <text class="author-name">{{ item.sellerName }}</text>
                  <view class="verify-badge" :class="{ green: item.verifiedType === 'green' }">V</view>
                </view>
                <text class="author-inst">{{ item.school }} / {{ item.college }}</text>
              </view>
            </view>
            <text class="topbar-icon">⋯</text>
          </view>

          <view class="poster-box" @tap="openInstrument(item.id)">
            <view class="poster-bg" :class="item.posterTheme"></view>
            <view class="poster-content">
              <view class="poster-topline">
                <view v-if="item.remote" class="remote-pill">支持远程实验</view>
                <view class="price-chip">¥{{ item.price }} /天</view>
              </view>
              <view>
                <view class="poster-title">{{ item.name }}</view>
                <view class="poster-meta">{{ item.location }} · {{ item.category }}</view>
              </view>
            </view>
          </view>

          <view class="desc-block" style="margin-top: 18rpx;">
            <text class="desc-strong">{{ item.sellerName }}</text>
            <text>{{ item.desc }}</text>
          </view>

          <view class="micro-note">
            <text>⌘</text>
            <text>{{ item.servicePackage }}</text>
          </view>

          <text class="time-note">2 小时前 · {{ item.location }}</text>
        </view>
      </view>
    </view>

    <BottomTabBar current="/pages/home/index" />
  </view>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import BottomTabBar from '../../components/BottomTabBar.vue'
import { callService } from '../../common/service'

const loading = ref(true)
const categories = ref(['全部推荐', '海洋观测', '地质灾害', '生物材料', '化学分析'])
const homeData = ref({ hero: {}, stats: [], featuredInstruments: [] })

onMounted(async () => {
  homeData.value = await callService('getHomeData')
  loading.value = false
})

function goPage(url) {
  uni.navigateTo({ url })
}

function openInstrument(id) {
  uni.navigateTo({ url: `/pages/equipment-detail/index?id=${id}` })
}

function openCategory(category) {
  uni.reLaunch({ url: `/pages/category/index?category=${encodeURIComponent(category)}` })
}
</script>
